package com.cg.banking.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

import com.cg.banking.util.BankingDBUtil;

@Component("bankingServices")
public class BankingServicesImpl implements BankingServices
{
	@Autowired
	private AccountDAO accountDAO;
	//@Autowired
	private TransactionDAO transactionDAO ;
	int count = 1;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException 
	{
		if(account.getAccountBalance() < 1000.0f) 
		{
			throw new  InvalidAmountException("Minimum amount should be above than Rs 1000");
		}
		
		if(account.getAccountType().equals("Savings") || account.getAccountType().equals("Current")) {
		account = new Account();
		account.setAccountStatus("Active");
		account.transactions = new HashMap<>();
		account = accountDAO.save(account);
		return account;
		}
		else {
		
			 throw new InvalidAccountTypeException("Invalid Account Type Exception! Please try Again");
		}
	}

	@Override                                     
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException 
	{
		 Account account = accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account Not Found For: "+ accountNo));
		float currentAmount =  account.getAccountBalance() + amount;
		account.setAccountBalance(currentAmount);
		Transaction transaction = new Transaction();
		
		transaction.setTransactionType(BankingDBUtil.getDEPOSIT_STATUS());
		transaction.setAmount(amount);
		transaction.setAccount(account);
		//account.transactions.put(BankingDBUtil.getTRANSACTION_ID(),transaction);
		this.accountDAO.save(account);
		transactionDAO.save(transaction);
		return currentAmount;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, long pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServiceDownException, AccountBlockedException {
		Account account = accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account Not Found For: "+ accountNo));
		float newAmount =account.getAccountBalance();
		getAccountDetails(accountNo);
		if(pinNumber == account.getPinNumber())
		{
			newAmount = account.getAccountBalance() - amount;
			account.setAccountBalance(newAmount);
			Transaction transaction = new Transaction();
			transaction.setTransactionType(BankingDBUtil.getWITHDRAW_STATUS());
			transaction.setAmount(newAmount);		
			transaction.setAccount(account);
			account.transactions.put(BankingDBUtil.getTRANSACTION_ID(),transaction);
			this.accountDAO.save(account);
			transactionDAO.save(transaction);
			return newAmount;
		}
			else if(pinNumber != account.getPinNumber())
		{
			count++;
			if(count % 4!=0)
			   throw new InvalidPinNumberException("Enter Valid Pin Number");
			if(count % 4 == 0)
			{
				account.setAccountStatus("Blocked");
				throw new AccountBlockedException("Sorry Your Account Has Been Blocked!");
			}
		float currentAmount = account.getAccountBalance();
		if(amount > currentAmount)
			throw new InsufficientAmountException("Insufficient Amount in the Account! " + accountNo);
		}
	return newAmount;
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServiceDownException, AccountBlockedException {
		Account account = accountDAO.findById(accountNoFrom).orElseThrow(()->new AccountNotFoundException("Account Not Found For: "+ accountNoFrom));
		withdrawAmount(accountNoFrom, transferAmount,pinNumber);
		getAccountDetails(accountNoTo);
		account = accountDAO.findById(accountNoTo).orElseThrow(()->new AccountNotFoundException("Account Not Found For: "+ accountNoTo));
		depositAmount(accountNoTo,transferAmount);
		getAccountDetails(accountNoFrom);
		Transaction transaction = new Transaction();
		transaction.setTransactionType(BankingDBUtil.getFUND_TRANSFER_TRANSACTION_STATUS());
		transaction.setAmount(transferAmount);		
		transaction.setAccount(account);
		return true;
	}
    @Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServiceDownException {
		Account account = accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account Not Found For: "+ accountNo));
		return account;
		
	}
   @Override
	public List<Account> getAllAccountDetails() throws BankingServiceDownException {
		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws AccountNotFoundException, BankingServiceDownException {
		return transactionDAO.findAll();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException, AccountBlockedException {
		Account account = accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account Not Found For: "+ accountNo));
		return account.getAccountStatus();
	}

}
